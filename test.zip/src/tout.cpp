int tout(){

    return 1;
}