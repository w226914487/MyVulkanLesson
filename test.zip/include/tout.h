#include <iostream>

int tout();